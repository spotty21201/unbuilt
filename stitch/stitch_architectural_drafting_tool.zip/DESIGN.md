---
name: Tectonic Precision CAD
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#ffffff'
  on-tertiary: '#003825'
  tertiary-container: '#68fcbf'
  on-tertiary-container: '#007350'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: '0'
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: -0.01em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0.02em
  code-dense:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0.04em
spacing:
  gutter: 0.5rem
  margin: 0.5rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style
The brand personality is uncompromisingly utilitarian, surgical, and silent. Built for architects, landscape urbanists, and structural computational designers, the UI acts as a calibrated instrument rather than an expressive canvas. It evokes the quiet, focused discipline of a physical drafting table outfitted with precision technical pens, stainless steel parallel rulers, and drafting film.

The visual direction follows a blend of **Technical Minimalism** and **Swiss Precision Tooling**:
- Uncluttered viewport supremacy: Chrome exists solely to support spatial manipulation and numeric telemetry.
- Utilitarian density: Compact tool assemblies, microscopic hairline rules, and zero frivolous ornamentation.
- Pure informational clarity: High visual yield per square millimeter, allowing users to cross-reference zoning envelopes, FAR calculations, solar envelopes, and tectonic cross-sections without context-switching.

## Colors
The system is built upon an absolute, temperature-neutral grayscale canvas paired with surgical functional accents. Color serves strictly as semantic notation (telemetry, vectors, environmental analysis), never as decoration.

### Grayscale Spectrum
- Surface Base (`#121212`): Root application background and viewport framing.
- Surface Elevated / Panels (`#1C1C1C`): Floating inspector pallets, contextual tool trays, dock dividers.
- Surface Inset / Track (`#262626`): Input troughs, disabled chips, viewport rulers.
- Hairline / Structural Rule (`#262626` lightened to `#333333` on interactive boundaries): 1px structural framing.
- Text Muted / Dimensions (`#737373` / `#A3A3A3`): Auxiliary dimensional readouts, coordinate metadata, unit labels.
- Text High-Yield (`#F5F5F5` to `#FFFFFF`): Primary numeric inputs, geometry labels, layer identifiers.

### Tactical Accents
- Technical Slate Cyan (`#38BDF8`): Circulation lines, right-of-way alignments, active vector selection, coordinate snapping guides.
- Structural Open-Space Green (`#34D399`): Pervious surface envelopes, vegetation index readouts, positive delta metrics.
- Warning / Envelope Breach Amber (`#FBBF24`): Setback violations, height restriction limit warnings.

## Typography
Typography is split into dual disciplines: structural neo-grotesque (`Geist` / `Inter`) for panel taxonomy and descriptive UI labels, and calibrated monospaced (`JetBrains Mono`) for all coordinate values, angles, dimensional readouts, and calculation panels.

- Tabular alignment is enforced everywhere metrics appear; monospaced digits prevent jitter during real-time dragging, rotation, or parametric slicing.
- Micro-scale hierarchy: The system intentionally caps primary viewport overlays at 13px, letting the drafting viewport dominate the designer's cognitive focus.
- Monospaced labels use explicit uppercase tracking at small scales (9–10px) to mirror blueprint annotation conventions.

## Layout & Spacing
The layout implements an edge-to-edge docking model optimized for multi-monitor workstations, high-DPI displays, and complex spatial coordination:

- Viewport Primacy: Top status bars, left-side drawing tool ribbons, and right-hand contextual attribute panels are pegged to strict widths (`240px` to `320px`). The remaining 80%+ screen real estate belongs unconditionally to the CAD canvas.
- 4px Base Rhythm: All micro-spacers, icon toolboxes, and parameter gutters align to multiples of 4px (`space-xs` = 2px, `space-sm` = 4px, `space-md` = 8px).
- Panel Margins: Outer window frames use a razor-thin `0.5rem` (8px) margin or dock flush to screen boundaries with zero outer clearance.
- Responsive Behavior:
  - Large Workstations (>1920px): Floating HUD inspectors and secondary parametric tables pin alongside viewport splitters.
  - Laptop / Compact (1024px–1440px): Right-hand inspector stacks into collapsed icon-tab rails; panels toggle on demand via keyboard shortcuts (`Tab`, `V`, `I`).
  - Tablet Inspection Mode: Panels slide into an off-canvas drawer; canvas gestures supersede UI manipulation.

## Elevation & Depth
Depth is produced via **Tonal Stacking and Crisp Hairline Borders**, strictly eschewing heavy blur shadows and diffuse drop shadows that degrade technical precision.

- Hairlines as Separators: Layer separation is dictated by `1px solid #262626` (or `#333333` on floating components). No rounded blurry edges; every panel is a hard-edged structural volume.
- Level 0 (Base Canvas): `#121212` background, infinity grid in `#1E1E1E` with major grid units in `#262626`.
- Level 1 (Docked Palettes & Trays): `#171717` flat fill, bordered by a 1px inner or perimeter boundary of `#262626`.
- Level 2 (Floating Precision Inspectors & Menus): `#1F1F1F` background, 1px perimeter border `#404040`, accompanied by an ultra-tight, sharp ambient shadow (`0 2px 4px rgba(0, 0, 0, 0.6)`) solely to delineate overlay overlaps above drafting vectors.
- Level 3 (Modal Alerts & Setback Breaches): `#242424` with a high-contrast `#525252` border.

## Shapes
The shape language is strictly **Sharp (`0`)**. 
- Corner radius is `0px` across buttons, inputs, floating inspectors, tool palettes, tabs, context menus, and metric chips.
- This rectilinear discipline reinforces architectural precision, honors CAD coordinate systems, and maximizes usable pixel boundaries within dense toolbars.
- Selection rings and bounding boxes use zero-radius, non-antialiased hairlines with square 4px anchor handles.

## Components

### Action & Draw Tools (Buttons)
- **Base Tool Button**: Square aspect ratio (28x28px or 24x24px), 0px radius, flat background transparent. Icon centered (14px stroke weight 1.25px).
- **Hover State**: Background `#262626`, border `1px solid #404040`.
- **Active / Engaged Tool**: Background `#F5F5F5`, icon fill/stroke `#121212`.
- **Secondary Action Button**: Height 24px, monospaced 11px label, background `#1F1F1F`, border `1px solid #333333`, color `#D4D4D4`.

### Numeric Metric Chips & Coordinates
- Fixed-height inline indicators (20px). JetBrains Mono 10px.
- Background `#1A1A1A`, hairline outline `1px solid #2A2A2A`.
- Left-edge functional accent pip (2px wide) colored `#38BDF8` (circulation/length), `#34D399` (FAR/green space), or `#FBBF24` (variance warning).

### Parameter & Coordinate Inputs
- Compact height (22px), background `#141414`, border `1px solid #2D2D2D`. Text set in monospaced 11px `#E5E5E5`.
- Focus State: Border switches directly to `1px solid #38BDF8` without glowing halos.
- Integrated Units: Fixed unit suffixes (e.g., `m²`, `mm`, `°`, `%`) right-aligned in `#737373`.

### Layer & Tree Lists
- Row height: 22px fixed. Hover state: `#1E1E1E`.
- Indentation: 12px per hierarchy level connected by 1px dotted guide rules.
- Layer color indicator: 8x8px square swatch flush to the label.
- Visibility / Lock toggles: Minimalist 12px icon toggles with `#525252` inactive and `#F5F5F5` active states.

### Checkboxes & Segmented Radios
- **Checkboxes**: 12x12px square box, 0px border-radius, `1px solid #525252`. Checked state fills box with `#E5E5E5` containing a `#121212` 1px checkmark.
- **Segmented Controls**: Integrated toolbar pill-free group. 0px radius, bounded by `1px solid #262626`. Selected segment: `#2E2E2E` with white text.

### Inspection Cards & Docked Panels
- Panel header: 24px height, background `#171717`, border-bottom `1px solid #262626`, uppercase 10px tracked label.
- Content body: Flat `#141414`, 8px padding (`space-md`). Data organized in two-column key/value tables with right-aligned numeric telemetry.